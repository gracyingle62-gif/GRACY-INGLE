# Phishing Website Detection Using Python

**Student project for IBM SkillsBuild Cyber Security 2026 (BharatCares submission).**

## Project description
This beginner-friendly educational tool screens a URL for a small set of common phishing warning indicators. It uses explainable heuristic rules and prints the reasons for its score. It does not visit websites, check live reputation, or determine with certainty whether a URL is malicious.

## Technologies
- Python 3
- Jupyter Notebook
- pandas
- Matplotlib
- Python standard library (`urllib.parse`, `re`, `ipaddress`)

## Dataset
The notebook runs using illustrative examples and does not require a dataset. For a future machine-learning extension, see the UCI Phishing Websites dataset:
https://archive.ics.uci.edu/dataset/327/phishing+websites

## Setup and run
1. Install Python 3 and Jupyter Notebook, or open the notebook in Google Colab.
2. Download the project files.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Open `GracyIngle_PhishingWebsiteDetection.ipynb`.
5. Run the cells from top to bottom.
6. Use the final input cell to screen a URL if desired. Do not paste URLs containing passwords, session tokens, or other private information.

## Main features
- Parses a URL and extracts its host.
- Checks a small set of warning indicators.
- Provides a heuristic score and reasons.
- Displays example results in a table and bar chart.

## Safety and limitations
The score is not a probability or a definitive verdict. False positives and false negatives are possible. Do not click suspicious links or provide credentials based on this tool's output. Use trusted security software and official channels to verify messages.

## Files
- `GracyIngle_PhishingWebsiteDetection.ipynb` — project code and explanation
- `requirements.txt` — Python dependencies
- `GracyIngle_PhishingWebsiteDetection_ProjectReport.docx` — project documentation
